# mb.valueSlider

__An open source jQuery component to make a value slider.__

![mb.bgndGallery](http://dl.dropbox.com/u/1976976/gitHub//mb.valueSlider.jpg)

## [go to the demo](http://pupunzi.com/#mb.components/mb.valueSlider/valueSlider.html)
## [go to the Doc](http://wiki.github.com/pupunzi/jquery.mb.valueSlider/)


[jquery.mb.components](http://pupunzi.com/), another way of thinking the web