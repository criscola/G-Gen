### Envato Tuts+ Tutorial: Smooth Page Transition with History Web API
#### Instructor: Thoriq Firdaus

In this tutorial we are going to build a static website with so called "History Web API". In a nutshell, the API is used to alter the browser history. It allows us to load a new URL, change the page title, at the same time record it as a new visiting history in the browser without having to actually load the page.

**Available on Tuts+ April 2016**

[View the demo](http://tutsplus.github.io/smooth-page-transition-with-history-web-api)
